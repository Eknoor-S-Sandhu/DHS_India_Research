infix using "C:\NFHS\Others\CasteTribe.dat.dct"

label variable ctstate  "State"
label variable ctpsu    "PSU"
label variable cthouse  "Household"
label variable ctind    "Individual"
label variable ctquest  "Question"
label variable ctresp   "Response to Caste/Tribe"

#delimit ;
label define CTSTATE 
     1 "[JM] Jammu and Kashmir"
     2 "[HP] Himachal Pradesh"
     3 "[PJ] Punjab"
     5 "[UC] Uttaranchal"
     6 "[HR] Haryana"
     7 "[DL] Delhi"
     8 "[RJ] Rajasthan"
     9 "[UP] Uttar Pradesh"
    10 "[BH] Bihar"
    11 "[SK] Sikkim"
    12 "[AR] Arunachal Pradesh"
    13 "[NA] Nagaland"
    14 "[MN] Manipur"
    15 "[MZ] Mizoram"
    16 "[TR] Tripura"
    17 "[MG] Meghalaya"
    18 "[AS] Assam"
    19 "[WB] West Bengal"
    20 "[JH] Jharkhand"
    21 "[OR] Orissa"
    22 "[CH] Chhattisgarh"
    23 "[MP] Madhya Pradesh"
    24 "[GJ] Gujarat"
    27 "[MH] Maharashtra"
    28 "[AP] Andhra Pradesh"
    29 "[KA] Karnataka"
    30 "[GO] Goa"
    32 "[KE] Kerala"
    33 "[TN] Tamil Nadu"
;
label define CTQUEST 
     1 "Household (QH45)"
     2 "Woman (Q117)"
     3 "Man (QM119)"
;

#delimit cr
label values ctstate  CTSTATE 
label values ctquest  CTQUEST 
