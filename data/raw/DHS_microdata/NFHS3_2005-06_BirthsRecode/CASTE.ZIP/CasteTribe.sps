DATA LIST FILE='C:\NFHS\Others\CasteTribe.dat' RECORDS=1
/
 CTSTATE     1-2   
 CTPSU       3-5   
 CTHOUSE     6-9   
 CTIND      10-11  
 CTQUEST    12-12  
 CTRESP     13-72   (A)
.
VARIABLE LABELS
 CTSTATE  "State"
/CTPSU    "PSU"
/CTHOUSE  "Household"
/CTIND    "Individual"
/CTQUEST  "Question"
/CTRESP   "Response to Caste/Tribe"
.
VALUE LABELS
 CTSTATE 
     1 "[JM] Jammu and Kashmir"
     2 "[HP] Himachal Pradesh"
     3 "[PJ] Punjab"
     5 "[UC] Uttaranchal"
     6 "[HR] Haryana"
     7 "[DL] Delhi"
     8 "[RJ] Rajasthan"
     9 "[UP] Uttar Pradesh"
    10 "[BH] Bihar"
    11 "[SK] Sikkim"
    12 "[AR] Arunachal Pradesh"
    13 "[NA] Nagaland"
    14 "[MN] Manipur"
    15 "[MZ] Mizoram"
    16 "[TR] Tripura"
    17 "[MG] Meghalaya"
    18 "[AS] Assam"
    19 "[WB] West Bengal"
    20 "[JH] Jharkhand"
    21 "[OR] Orissa"
    22 "[CH] Chhattisgarh"
    23 "[MP] Madhya Pradesh"
    24 "[GJ] Gujarat"
    27 "[MH] Maharashtra"
    28 "[AP] Andhra Pradesh"
    29 "[KA] Karnataka"
    30 "[GO] Goa"
    32 "[KE] Kerala"
    33 "[TN] Tamil Nadu"
/CTQUEST 
     1 "Household (QH45)"
     2 "Woman (Q117)"
     3 "Man (QM119)"
.
EXECUTE.
