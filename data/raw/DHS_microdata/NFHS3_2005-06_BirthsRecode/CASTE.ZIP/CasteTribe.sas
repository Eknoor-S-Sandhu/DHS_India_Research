libname user 'C:\NFHS\Others';
Proc format;
  value F00001_
     1 = "[JM] Jammu and Kashmir"
     2 = "[HP] Himachal Pradesh"
     3 = "[PJ] Punjab"
     5 = "[UC] Uttaranchal"
     6 = "[HR] Haryana"
     7 = "[DL] Delhi"
     8 = "[RJ] Rajasthan"
     9 = "[UP] Uttar Pradesh"
    10 = "[BH] Bihar"
    11 = "[SK] Sikkim"
    12 = "[AR] Arunachal Pradesh"
    13 = "[NA] Nagaland"
    14 = "[MN] Manipur"
    15 = "[MZ] Mizoram"
    16 = "[TR] Tripura"
    17 = "[MG] Meghalaya"
    18 = "[AS] Assam"
    19 = "[WB] West Bengal"
    20 = "[JH] Jharkhand"
    21 = "[OR] Orissa"
    22 = "[CH] Chhattisgarh"
    23 = "[MP] Madhya Pradesh"
    24 = "[GJ] Gujarat"
    27 = "[MH] Maharashtra"
    28 = "[AP] Andhra Pradesh"
    29 = "[KA] Karnataka"
    30 = "[GO] Goa"
    32 = "[KE] Kerala"
    33 = "[TN] Tamil Nadu"
     ;
  value F00002_
     1 = "Household (QH45)"
     2 = "Woman (Q117)"
     3 = "Man (QM119)"
     ;
Data user.CasteTribe;
  attrib CTSTATE  format=F00001_. label="State";
  attrib CTPSU    label="PSU";
  attrib CTHOUSE  label="Household";
  attrib CTIND    label="Individual";
  attrib CTQUEST  format=F00002_. label="Question";
  attrib CTRESP   length=$60 label="Response to Caste/Tribe";
infile 'C:\NFHS\Others\CasteTribe.dat' LRECL=72 MISSOVER ;
    input
    @1    CTSTATE  2.0
    @3    CTPSU    3.0
    @6    CTHOUSE  4.0
    @10   CTIND    2.0
    @12   CTQUEST  1.0
    @13   CTRESP   $60.
    ;
Run;
